﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSaltorFresh
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSaltorFresh))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnSalt = New System.Windows.Forms.Button()
        Me.btnFresh = New System.Windows.Forms.Button()
        Me.lblQ1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Ravie", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.DarkRed
        Me.lblTitle.Location = New System.Drawing.Point(13, 13)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(454, 34)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Fishing Rod/Reel Selector"
        '
        'btnSalt
        '
        Me.btnSalt.BackColor = System.Drawing.Color.White
        Me.btnSalt.Font = New System.Drawing.Font("Ravie", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalt.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnSalt.Location = New System.Drawing.Point(165, 187)
        Me.btnSalt.Name = "btnSalt"
        Me.btnSalt.Size = New System.Drawing.Size(144, 38)
        Me.btnSalt.TabIndex = 1
        Me.btnSalt.Text = "Saltwater"
        Me.btnSalt.UseVisualStyleBackColor = False
        '
        'btnFresh
        '
        Me.btnFresh.BackColor = System.Drawing.Color.White
        Me.btnFresh.Font = New System.Drawing.Font("Ravie", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFresh.ForeColor = System.Drawing.Color.DarkGreen
        Me.btnFresh.Location = New System.Drawing.Point(505, 187)
        Me.btnFresh.Name = "btnFresh"
        Me.btnFresh.Size = New System.Drawing.Size(167, 38)
        Me.btnFresh.TabIndex = 2
        Me.btnFresh.Text = "Freshwater"
        Me.btnFresh.UseVisualStyleBackColor = False
        '
        'lblQ1
        '
        Me.lblQ1.AutoSize = True
        Me.lblQ1.Font = New System.Drawing.Font("Ravie", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQ1.ForeColor = System.Drawing.Color.DarkRed
        Me.lblQ1.Location = New System.Drawing.Point(28, 97)
        Me.lblQ1.Name = "lblQ1"
        Me.lblQ1.Size = New System.Drawing.Size(745, 30)
        Me.lblQ1.TabIndex = 3
        Me.lblQ1.Text = "Will you be fishing in freshwater or saltwater?"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Ravie", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkRed
        Me.Label1.Location = New System.Drawing.Point(383, 194)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 22)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "or"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(2, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(800, 448)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'frmSaltorFresh
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblQ1)
        Me.Controls.Add(Me.btnFresh)
        Me.Controls.Add(Me.btnSalt)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmSaltorFresh"
        Me.Text = "Saltwater or Freshwater"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents btnSalt As Button
    Friend WithEvents btnFresh As Button
    Friend WithEvents lblQ1 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
