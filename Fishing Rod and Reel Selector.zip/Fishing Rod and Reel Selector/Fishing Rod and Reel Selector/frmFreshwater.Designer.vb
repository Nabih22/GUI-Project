﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFreshwater
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFreshwater))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnLargemouthBass = New System.Windows.Forms.Button()
        Me.btnGar = New System.Windows.Forms.Button()
        Me.btnSmallmouth = New System.Windows.Forms.Button()
        Me.btnTrout = New System.Windows.Forms.Button()
        Me.btnCatfish = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Ravie", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label1.Location = New System.Drawing.Point(17, 9)
        Me.Label1.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(454, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fishing Rod/Reel Selector"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label2.Location = New System.Drawing.Point(244, 209)
        Me.Label2.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(306, 26)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Freshwater Species :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Ravie", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label3.Location = New System.Drawing.Point(98, 111)
        Me.Label3.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(598, 30)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Which species would you like to catch?"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 2)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(8, 6, 8, 6)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(793, 651)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(341, 530)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(130, 52)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Go Back"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'btnLargemouthBass
        '
        Me.btnLargemouthBass.BackColor = System.Drawing.Color.White
        Me.btnLargemouthBass.Location = New System.Drawing.Point(103, 263)
        Me.btnLargemouthBass.Name = "btnLargemouthBass"
        Me.btnLargemouthBass.Size = New System.Drawing.Size(291, 36)
        Me.btnLargemouthBass.TabIndex = 6
        Me.btnLargemouthBass.Text = "Largemouth Bass"
        Me.btnLargemouthBass.UseVisualStyleBackColor = False
        '
        'btnGar
        '
        Me.btnGar.BackColor = System.Drawing.Color.White
        Me.btnGar.Location = New System.Drawing.Point(103, 352)
        Me.btnGar.Name = "btnGar"
        Me.btnGar.Size = New System.Drawing.Size(291, 36)
        Me.btnGar.TabIndex = 7
        Me.btnGar.Text = "Gar"
        Me.btnGar.UseVisualStyleBackColor = False
        '
        'btnSmallmouth
        '
        Me.btnSmallmouth.BackColor = System.Drawing.Color.White
        Me.btnSmallmouth.Location = New System.Drawing.Point(430, 263)
        Me.btnSmallmouth.Name = "btnSmallmouth"
        Me.btnSmallmouth.Size = New System.Drawing.Size(266, 36)
        Me.btnSmallmouth.TabIndex = 8
        Me.btnSmallmouth.Text = "Smallmouth Bass"
        Me.btnSmallmouth.UseVisualStyleBackColor = False
        '
        'btnTrout
        '
        Me.btnTrout.BackColor = System.Drawing.Color.White
        Me.btnTrout.Location = New System.Drawing.Point(249, 452)
        Me.btnTrout.Name = "btnTrout"
        Me.btnTrout.Size = New System.Drawing.Size(301, 36)
        Me.btnTrout.TabIndex = 9
        Me.btnTrout.Text = "Trout"
        Me.btnTrout.UseVisualStyleBackColor = False
        '
        'btnCatfish
        '
        Me.btnCatfish.BackColor = System.Drawing.Color.White
        Me.btnCatfish.Location = New System.Drawing.Point(430, 352)
        Me.btnCatfish.Name = "btnCatfish"
        Me.btnCatfish.Size = New System.Drawing.Size(266, 36)
        Me.btnCatfish.TabIndex = 10
        Me.btnCatfish.Text = "Catfish"
        Me.btnCatfish.UseVisualStyleBackColor = False
        '
        'frmFreshwater
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(17.0!, 26.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(794, 654)
        Me.Controls.Add(Me.btnCatfish)
        Me.Controls.Add(Me.btnTrout)
        Me.Controls.Add(Me.btnSmallmouth)
        Me.Controls.Add(Me.btnGar)
        Me.Controls.Add(Me.btnLargemouthBass)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.DarkGreen
        Me.Margin = New System.Windows.Forms.Padding(8, 6, 8, 6)
        Me.Name = "frmFreshwater"
        Me.Text = "Freshwater"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents btnLargemouthBass As Button
    Friend WithEvents btnGar As Button
    Friend WithEvents btnSmallmouth As Button
    Friend WithEvents btnTrout As Button
    Friend WithEvents btnCatfish As Button
End Class
