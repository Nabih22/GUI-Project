﻿' Project Name: Fishing Rod and Reel Selector
' Author: Tyler Nabih
' Objective: To help first time fishermen and casual fishermen to target and catch a specific species with a Rod and Reel recommendation to catch it.
Public Class frmSaltorFresh
    Private Sub btnSalt_Click(sender As Object, e As EventArgs) Handles btnSalt.Click
        Dim frmThird As New frmSaltwater

        'Hide this form and show the Saltwater form
        Hide()
        frmThird.ShowDialog()
    End Sub

    Private Sub btnFresh_Click(sender As Object, e As EventArgs) Handles btnFresh.Click
        Dim frmSecond As New frmFreshwater

        'Hide this form and show the Freshwater Form
        Hide()
        frmSecond.ShowDialog()
    End Sub

    Private Sub frmSaltorFresh_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
