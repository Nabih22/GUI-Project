﻿Public Class frmFreshwater
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frmFourth As New frmSaltorFresh

        'Hide this form and show the Main Menu form asking the user to select Salt or Freshwater.
        Hide()
        frmFourth.ShowDialog()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub frmFreshwater_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnLargemouthBass_Click(sender As Object, e As EventArgs) Handles btnLargemouthBass.Click
        Dim frmEleventh As New frmBass

        'Hide this form and open up the Largemouth Bass form for the user.
        Hide()
        frmEleventh.ShowDialog()
    End Sub

    Private Sub btnSmallmouth_Click(sender As Object, e As EventArgs) Handles btnSmallmouth.Click
        Dim frmTwelth As New frmSmallmouth

        'Hide this form and open up the Smallmouth Bass form for the user.
        Hide()
        frmTwelth.ShowDialog()
    End Sub

    Private Sub btnGar_Click(sender As Object, e As EventArgs) Handles btnGar.Click
        Dim frmThirteenth As New frmGar

        'Hide this form and open up the Gar form for the user.
        Hide()
        frmThirteenth.ShowDialog()
    End Sub

    Private Sub btnCatfish_Click(sender As Object, e As EventArgs) Handles btnCatfish.Click
        Dim frmFourteenth As New frmCatfish

        'Hide this form and open up the Catfish form for the user.
        Hide()
        frmFourteenth.ShowDialog()
    End Sub

    Private Sub btnTrout_Click(sender As Object, e As EventArgs) Handles btnTrout.Click
        Dim frmFifteenth As New frmTrout

        'Hide this form and open up the Trout form for the user.
        Hide()
        frmFifteenth.ShowDialog()
    End Sub
End Class