﻿Public Class frmSaltwater
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frmFourth As New frmSaltorFresh

        'Hide this form and show the Main Menu form that asks the user for Salt or Freshwater.
        Hide()
        frmFourth.ShowDialog()
    End Sub

    Private Sub frmSaltwater_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnRedfish_Click(sender As Object, e As EventArgs) Handles btnRedfish.Click
        Dim frmSixth As New frmRedfish

        'Hide this form and open up the Red Drum form for the user.
        Hide()
        frmSixth.ShowDialog()
    End Sub

    Private Sub btnShark_Click(sender As Object, e As EventArgs) Handles btnShark.Click
        Dim frmSeventh As New frmShark

        'Hide this form and open up the Shark form for the user.
        Hide()
        frmSeventh.ShowDialog()
    End Sub

    Private Sub btnRedSnapper_Click(sender As Object, e As EventArgs) Handles btnRedSnapper.Click
        Dim frmEighth As New frmRedSnapper

        'Hide this form and open up the Red Snapper form for the user.
        Hide()
        frmEighth.ShowDialog()
    End Sub

    Private Sub btnGrouper_Click(sender As Object, e As EventArgs) Handles btnGrouper.Click
        Dim frmNinth As New frmGrouper

        'Hide this form and open up the Grouper form for the user.
        Hide()
        frmNinth.ShowDialog()
    End Sub

    Private Sub btnPinfish_Click(sender As Object, e As EventArgs) Handles btnPinfish.Click
        Dim frmTenth As New frmPinfish

        'Hide this form and open up the Pinfish form for the user.
        Hide()
        frmTenth.ShowDialog()
    End Sub
End Class