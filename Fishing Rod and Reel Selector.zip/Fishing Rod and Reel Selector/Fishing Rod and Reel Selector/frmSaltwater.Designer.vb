﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSaltwater
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSaltwater))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnRedSnapper = New System.Windows.Forms.Button()
        Me.btnPinfish = New System.Windows.Forms.Button()
        Me.btnGrouper = New System.Windows.Forms.Button()
        Me.btnRedfish = New System.Windows.Forms.Button()
        Me.btnShark = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Ravie", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(454, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fishing Rod/Reel Selector"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Ravie", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(98, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(598, 30)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Which species would you like to catch?"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(258, 182)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(285, 26)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Saltwater species :"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Button1.Location = New System.Drawing.Point(335, 559)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(131, 57)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Go Back"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(1, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(793, 654)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'btnRedSnapper
        '
        Me.btnRedSnapper.BackColor = System.Drawing.Color.White
        Me.btnRedSnapper.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRedSnapper.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnRedSnapper.Location = New System.Drawing.Point(103, 327)
        Me.btnRedSnapper.Name = "btnRedSnapper"
        Me.btnRedSnapper.Size = New System.Drawing.Size(241, 38)
        Me.btnRedSnapper.TabIndex = 6
        Me.btnRedSnapper.Text = "Red Snapper"
        Me.btnRedSnapper.UseVisualStyleBackColor = False
        '
        'btnPinfish
        '
        Me.btnPinfish.BackColor = System.Drawing.Color.White
        Me.btnPinfish.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPinfish.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnPinfish.Location = New System.Drawing.Point(282, 426)
        Me.btnPinfish.Name = "btnPinfish"
        Me.btnPinfish.Size = New System.Drawing.Size(241, 38)
        Me.btnPinfish.TabIndex = 7
        Me.btnPinfish.Text = "Pinfish"
        Me.btnPinfish.UseVisualStyleBackColor = False
        '
        'btnGrouper
        '
        Me.btnGrouper.BackColor = System.Drawing.Color.White
        Me.btnGrouper.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGrouper.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnGrouper.Location = New System.Drawing.Point(455, 327)
        Me.btnGrouper.Name = "btnGrouper"
        Me.btnGrouper.Size = New System.Drawing.Size(241, 38)
        Me.btnGrouper.TabIndex = 8
        Me.btnGrouper.Text = "Grouper"
        Me.btnGrouper.UseVisualStyleBackColor = False
        '
        'btnRedfish
        '
        Me.btnRedfish.BackColor = System.Drawing.Color.White
        Me.btnRedfish.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRedfish.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnRedfish.Location = New System.Drawing.Point(103, 244)
        Me.btnRedfish.Name = "btnRedfish"
        Me.btnRedfish.Size = New System.Drawing.Size(241, 38)
        Me.btnRedfish.TabIndex = 9
        Me.btnRedfish.Text = "Red Drum"
        Me.btnRedfish.UseVisualStyleBackColor = False
        '
        'btnShark
        '
        Me.btnShark.BackColor = System.Drawing.Color.White
        Me.btnShark.Font = New System.Drawing.Font("Ravie", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShark.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnShark.Location = New System.Drawing.Point(455, 244)
        Me.btnShark.Name = "btnShark"
        Me.btnShark.Size = New System.Drawing.Size(241, 38)
        Me.btnShark.TabIndex = 10
        Me.btnShark.Text = "Shark"
        Me.btnShark.UseVisualStyleBackColor = False
        '
        'frmSaltwater
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(794, 654)
        Me.Controls.Add(Me.btnShark)
        Me.Controls.Add(Me.btnRedfish)
        Me.Controls.Add(Me.btnGrouper)
        Me.Controls.Add(Me.btnPinfish)
        Me.Controls.Add(Me.btnRedSnapper)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmSaltwater"
        Me.Text = " "
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnRedSnapper As Button
    Friend WithEvents btnPinfish As Button
    Friend WithEvents btnGrouper As Button
    Friend WithEvents btnRedfish As Button
    Friend WithEvents btnShark As Button
End Class
